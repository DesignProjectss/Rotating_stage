class Curtain():
    def __init__():
        pass
    
    def close():
        print('curtain closed...')

    def draw():
        print('curtain fully opened')
    
    def open_to(width):
        pass
    
