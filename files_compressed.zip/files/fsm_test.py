#power on self test: tests all the hardware connected to the fsm before startup
def post():
  pass
