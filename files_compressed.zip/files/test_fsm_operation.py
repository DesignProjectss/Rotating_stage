import unittest
from rotate_stage_fsm import Transition, State, StateMachine  

class TestFsm(unittest.TestCase):
  """
  Test the operations of the fsm - The number of states
                                 - The Transition
                                 - The StateMachine
                                 - The State
  """
  pass
