class Lamp():

    def __init__(self):
        pass
    
    def flicker():
        print('Lamp flicker')
    
    def fade_in():
        print('Lamp faded in')
    
    def fade_out():
        print('Lamp faded out')
    
    def off():
        print('Lamp off')
    
    def on():
        print('Lamp on')
    
    